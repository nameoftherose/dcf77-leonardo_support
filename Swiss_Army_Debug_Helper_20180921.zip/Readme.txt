2018-08-05 UNTESTED
This version will try to implement a week day inconsistency constraint
1. max_unlocked_seconds initialized
2. get_overall_quality_factor() modified to return 0 in case of weekday inconsistency
   and set the inconsistentWeekDay flag
3. hour decoder reset (dcf77.h process_1_Hz_tick )
4. decoders reset when weekday inconsistency is detected:
     inconsistentWeekDay global variable set by get_overall_quality_factor()
5. Swiss_Army_Debug_Helper loop() scopeCount calculation modified
6. dcf77.h L1340 year_error_count calculation has been corrected
   inconsistentWeekDayCounter calculation added
7. The weekday calculation in get_overall_quality_factor() is only done
           if (date_quality_factor > 0 && weekday_quality_factor > 0)
   This delays the inconsistency detection, should be done every time
   Code has been modified so that the calculation always takes place

This is derived from dcf77_2017-10-26_1904.src.zip with the following changes:
1. The modifications to initialize the Clock to the free state and a compile-time
   time stamp was removed, as it did not improve performance.
2. The debug variables monitoring year error were moved from
   Swiss_Army_Debug_Helper.ino to dcf77.h L 1303, are now members of
   struct DCF77_Local_Clock 
3. static const int16_t max_total_adjust (dcf77.h L1564) was redefined from 6400
   to 1600 corresponding to 100ppm
